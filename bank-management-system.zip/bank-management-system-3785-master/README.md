# bank-management-system

conda activate bank

pip install django

pip install mysqlclient

python manage.py runserver


database: mybank_database
